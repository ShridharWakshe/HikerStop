package com.cdac.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HikerstopApplicationTests {

	@Test
	void contextLoads() {
	}

}
